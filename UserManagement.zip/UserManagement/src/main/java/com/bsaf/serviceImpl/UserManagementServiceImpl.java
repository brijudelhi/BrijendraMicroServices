package com.bsaf.serviceImpl;

import org.springframework.stereotype.Component;

import com.bsaf.request.TransactionBean;
import com.bsaf.request.UserManagementRequest;
import com.bsaf.response.UserManagementResponse;
import com.bsaf.service.IUserManagementService;


@Component
public class UserManagementServiceImpl implements IUserManagementService {

	UserManagementResponse userManagementResponse = null;
	
	@Override
	public UserManagementResponse getUserDetails(
			UserManagementRequest userManagementRequest,
			TransactionBean txnBean) throws Exception {
		// TODO Auto-generated method stub
		
		userManagementResponse.setName(userManagementRequest.getName());
		userManagementResponse.setEmail(userManagementRequest.getEmail());
		userManagementResponse.setPhone(userManagementRequest.getPhone());
		userManagementResponse.setAddress(userManagementRequest.getPrmAddress()+"||"+userManagementRequest.getSecAddress());
		
		return userManagementResponse;
	}

	

	

}
