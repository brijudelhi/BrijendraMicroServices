package com.bsaf.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserManagementResponse {

	@Override
	public String toString() {
		return "UserManagementResponse [name=" + name + ", email=" + email
				+ ", phone=" + phone + ", address=" + address + "]";
	}
	@JsonProperty(value = "Name", required = true)
	protected String name = null;
	@JsonProperty(value = "Email", required = true)
	protected String email = null;
	@JsonProperty(value = "Phone", required = true)
	protected int phone;
	@JsonProperty(value = "Address", required = true)
	protected String address=null;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
