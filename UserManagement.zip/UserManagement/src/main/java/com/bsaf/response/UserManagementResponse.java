package com.bsaf.response;

public class UserManagementResponse {

	@Override
	public String toString() {
		return "UserManagementResponse [name=" + name + ", email=" + email
				+ ", phone=" + phone + ", address=" + address + "]";
	}
	public String name = null;
	public String email = null;
	public int phone;
	public String address=null;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
