package com.bsaf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bsaf.request.TransactionBean;
import com.bsaf.request.UserManagementRequest;
import com.bsaf.response.UserManagementResponse;
import com.bsaf.service.IUserManagementService;





@RestController

public class UserManagementController {
	
	@Autowired IUserManagementService userManagementService;
	@RequestMapping(value = "/userManagement/v1", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public ResponseEntity<UserManagementResponse> getUpdateMemberV1(
			@RequestHeader(value = "correlationId", required = false) String correlationId,
			@RequestBody UserManagementRequest userManagementRequest) throws Exception{
		UserManagementResponse userManagementResponse = null;
		TransactionBean txnBean = new TransactionBean();
		txnBean.setCorrelationId(correlationId);
		txnBean.setUserManagementRequest(userManagementRequest);
		
		//Service layer call
		userManagementResponse = userManagementService.getUserDetails(userManagementRequest, txnBean);
		
		return new ResponseEntity<>(userManagementResponse,HttpStatus.OK);
		
	}

}
