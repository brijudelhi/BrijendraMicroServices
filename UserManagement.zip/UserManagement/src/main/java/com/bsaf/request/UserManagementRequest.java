package com.bsaf.request;

public class UserManagementRequest {
	
	public String name = null;
	public String email = null;
	public int phone;
	public String prmAddress = null;
	public String secAddress = null;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getPrmAddress() {
		return prmAddress;
	}
	public void setPrmAddress(String prmAddress) {
		this.prmAddress = prmAddress;
	}
	public String getSecAddress() {
		return secAddress;
	}
	public void setSecAddress(String secAddress) {
		this.secAddress = secAddress;
	}
	
	
	

}
