package com.bsaf.request;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserManagementRequest {
	@JsonProperty(value = "Name", required = true)
	protected String name = null;
	@JsonProperty(value = "Email", required = true)
	protected String email = null;
	@JsonProperty(value = "Phone", required = true)
	protected int phone;
	@JsonProperty(value = "PrmAddress", required = true)
	protected String prmAddress = null;
	@JsonProperty(value = "SecAddress", required = true)
	protected String secAddress = null;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getPrmAddress() {
		return prmAddress;
	}
	public void setPrmAddress(String prmAddress) {
		this.prmAddress = prmAddress;
	}
	public String getSecAddress() {
		return secAddress;
	}
	public void setSecAddress(String secAddress) {
		this.secAddress = secAddress;
	}
	
	
	

}
