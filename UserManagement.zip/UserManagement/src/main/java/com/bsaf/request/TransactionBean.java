package com.bsaf.request;



public class TransactionBean {
	
	public String correlationId=null;
	private UserManagementRequest userManagementRequest;
	public String getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	public UserManagementRequest getUserManagementRequest() {
		return userManagementRequest;
	}
	public void setUserManagementRequest(UserManagementRequest userManagementRequest) {
		this.userManagementRequest = userManagementRequest;
	}
	

}
