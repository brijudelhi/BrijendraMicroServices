package com.bsaf.service;

import com.bsaf.request.TransactionBean;
import com.bsaf.request.UserManagementRequest;
import com.bsaf.response.UserManagementResponse;



public interface IUserManagementService {
	public UserManagementResponse getUserDetails(UserManagementRequest  userManagementRequest, TransactionBean txnBean)throws Exception;

}
