package com.bsaf.serviceImplTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.bsaf.request.TransactionBean;
import com.bsaf.request.UserManagementRequest;
import com.bsaf.response.UserManagementResponse;

public class UserManagementServiceImplTest {

	//@SuppressWarnings("null")
	@Test
	public void getUserDetails(
			) throws Exception {
		// TODO Auto-generated method stub
		UserManagementRequest userManagementRequest =new UserManagementRequest();
		UserManagementResponse userManagementResponse = new UserManagementResponse();
		userManagementRequest.setName("Brijendra");
		userManagementRequest.setEmail("bkumar@gmail.com");
		userManagementRequest.setPhone(123456789);
		userManagementRequest.setPrmAddress("Gaur City");
		userManagementRequest.setSecAddress("Noida");
		
		userManagementResponse.setName(userManagementRequest.getName());
		userManagementResponse.setEmail(userManagementRequest.getEmail());
		userManagementResponse.setPhone(userManagementRequest.getPhone());
		userManagementResponse.setAddress(userManagementRequest.getPrmAddress()+"||"+userManagementRequest.getSecAddress());
		assertNotNull(userManagementResponse.toString());
		
	}
}
